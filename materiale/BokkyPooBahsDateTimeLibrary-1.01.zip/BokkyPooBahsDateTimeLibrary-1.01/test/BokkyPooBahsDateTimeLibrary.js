var dateTimeLibOutput={
  "contracts" : 
  {
    "BokkyPooBahsDateTimeLibrary.sol:BokkyPooBahsDateTimeLibrary" : 
    {
      "abi" : "[]",
      "bin" : "604c602c600b82828239805160001a60731460008114601c57601e565bfe5b5030600052607381538281f3fe73000000000000000000000000000000000000000030146080604052600080fdfea165627a7a72305820533aca9f692463073a88892cdcbf098b8bbc5960c260ebe5944be46b68523fc70029"
    }
  },
  "version" : "0.5.4+commit.9549d8ff.Darwin.appleclang"
};
